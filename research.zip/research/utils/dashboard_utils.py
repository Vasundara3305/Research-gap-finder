"""
Dashboard and Visualization Utilities for Research Gap Finder.
Generates:
1. Simple comparison bar chart of paper scores (highlighting the Best Paper)
2. Comparison data table
3. Summary metrics computation
4. Downloadable summary report (PDF via ReportLab & CSV)
"""

import io
from typing import Dict, List, Any
import pandas as pd
import plotly.graph_objects as go
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


def create_score_comparison_chart(analyzed_papers: List[Dict[str, Any]], best_paper_title: str) -> go.Figure:
    """
    Creates a clean, simple Plotly bar chart comparing the overall scores of all uploaded papers.
    Highlights the Best Paper / Selected Paper in green, while others are in soft blue.
    """
    if not analyzed_papers:
        return go.Figure()

    # Sort ascending for horizontal bar chart or descending for vertical
    papers_sorted = sorted(analyzed_papers, key=lambda x: x.get("overall_score", 0), reverse=False)

    short_titles = []
    scores = []
    bar_colors = []
    hover_texts = []

    for p in papers_sorted:
        title = p.get("title", "Untitled")
        short_title = title if len(title) <= 35 else title[:32] + "..."
        score = p.get("overall_score", 0)
        is_best = (title == best_paper_title)

        short_titles.append(short_title)
        scores.append(score)
        
        if is_best:
            bar_colors.append("#10b981")  # Emerald green for Best Paper
            hover_texts.append(f"<b>[SELECTED BEST PAPER]</b><br>{title}<br>Overall Score: {score}/100")
        else:
            bar_colors.append("#3b82f6")  # Blue for other papers
            hover_texts.append(f"{title}<br>Overall Score: {score}/100")

    fig = go.Figure(
        go.Bar(
            x=scores,
            y=short_titles,
            orientation="h",
            marker=dict(
                color=bar_colors,
                line=dict(color="#0f172a", width=1)
            ),
            text=[f" {s}/100 " for s in scores],
            textposition="auto",
            hoverinfo="text",
            hovertext=hover_texts
        )
    )

    fig.update_layout(
        title=dict(
            text="<b>Overall Quality Score Comparison (Out of 100)</b>",
            font=dict(size=15, color="#1e293b"),
            x=0.0
        ),
        xaxis=dict(
            title="Combined Quality Score (3 Criteria Weighted)",
            range=[0, 105],
            gridcolor="#f1f5f9",
            zeroline=False
        ),
        yaxis=dict(
            title="",
            autorange="reversed" # Highest on top
        ),
        plot_bgcolor="#ffffff",
        paper_bgcolor="#ffffff",
        margin=dict(l=10, r=20, t=50, b=40),
        height=max(260, len(analyzed_papers) * 65),
    )

    return fig


def create_criteria_breakdown_table(analyzed_papers: List[Dict[str, Any]], best_paper_title: str) -> pd.DataFrame:
    """
    Creates a clean comparison table of all papers across the 3 criteria and overall score.
    """
    rows = []
    for idx, p in enumerate(analyzed_papers):
        title = p.get("title", "Untitled")
        is_best = (title == best_paper_title)
        scores = p.get("scores", {})
        
        status_label = "[SELECTED BEST PAPER]" if is_best else f"Paper {idx + 1}"
        
        rows.append({
            "Status": status_label,
            "Paper Title": title,
            "Technical Rigor (1-10)": f"{scores.get('technical_rigor', 0):.1f}",
            "Experimental Validation (1-10)": f"{scores.get('experimental_validation', 0):.1f}",
            "Practical Impact (1-10)": f"{scores.get('practical_impact', 0):.1f}",
            "Overall Score": f"{p.get('overall_score', 0):.1f} / 100"
        })

    df = pd.DataFrame(rows)
    return df


def generate_summary_pdf_report(
    analyzed_papers: List[Dict[str, Any]],
    best_paper: Dict[str, Any],
    limitations: List[Dict[str, Any]],
    gaps: List[Dict[str, Any]],
    recommendations: List[Dict[str, Any]]
) -> bytes:
    """
    Compiles a clean, professional PDF summary report of the analysis using ReportLab.
    Contains:
    - Overview & Best Paper Selection
    - Score comparison of all papers
    - Limitations of the Selected Paper
    - Potential Research Gaps of the Selected Paper
    - Concrete Further Implementation Roadmap
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "ReportTitle",
        parent=styles["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=18,
        leading=22,
        textColor=colors.HexColor("#0f172a"),
        spaceAfter=4
    )
    subtitle_style = ParagraphStyle(
        "ReportSubtitle",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#64748b"),
        spaceAfter=15
    )
    h2_style = ParagraphStyle(
        "ReportH2",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=13,
        leading=16,
        textColor=colors.HexColor("#1e3a8a"),
        spaceBefore=14,
        spaceAfter=6
    )
    body_style = ParagraphStyle(
        "ReportBody",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9.5,
        leading=13.5,
        textColor=colors.HexColor("#334155"),
        spaceAfter=6
    )
    bullet_style = ParagraphStyle(
        "ReportBullet",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9.0,
        leading=13.0,
        textColor=colors.HexColor("#1e293b"),
        spaceAfter=4,
        leftIndent=15
    )

    story = []

    # Title & Subtitle
    story.append(Paragraph("Research Gap Finder - Comprehensive Academic Analysis Report", title_style))
    story.append(Paragraph("Final-Year B.Tech Project Evaluation Document | Automated Research Evaluation", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#0284c7"), spaceAfter=12))

    # Executive Summary & Best Paper Card
    story.append(Paragraph("1. Executive Summary & Best Paper Selection", h2_style))
    best_title = best_paper.get("title", "N/A") if best_paper else "N/A"
    best_score = best_paper.get("overall_score", 0) if best_paper else 0
    total_papers = len(analyzed_papers)

    summary_text = (
        f"A total of <b>{total_papers} research papers</b> were evaluated across the 3 core criteria: "
        f"<i>(1) Technical Rigor & Methodology Depth, (2) Experimental Validation & Results, and "
        f"(3) Practical Impact & Applicability</i>. Based on the combined weighted scoring, the designated "
        f"<b>Selected Paper (Best Paper)</b> is: <br/>"
        f"<b>&bull; Title:</b> {best_title}<br/>"
        f"<b>&bull; Combined Overall Score:</b> {best_score} / 100"
    )
    story.append(Paragraph(summary_text, body_style))

    # Table of all papers
    story.append(Spacer(1, 8))
    table_data = [["Paper Title", "Rigor (1-10)", "Validation (1-10)", "Impact (1-10)", "Overall Score"]]
    for p in analyzed_papers:
        s = p.get("scores", {})
        table_data.append([
            Paragraph(p.get("title", "Untitled")[:45] + ("..." if len(p.get("title", "")) > 45 else ""), body_style),
            f"{s.get('technical_rigor', 0):.1f}",
            f"{s.get('experimental_validation', 0):.1f}",
            f"{s.get('practical_impact', 0):.1f}",
            f"{p.get('overall_score', 0):.1f}/100"
        ])

    table = Table(table_data, colWidths=[240, 70, 85, 75, 65])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#f1f5f9")),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor("#0f172a")),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8.5),
        ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(table)

    # Section 2: Limitations of the Selected Paper ONLY
    story.append(Spacer(1, 10))
    story.append(Paragraph("2. Limitations of the Selected Paper (Best Paper ONLY)", h2_style))
    story.append(Paragraph(f"The following limitations were identified specifically in <i>{best_title}</i>:", body_style))
    for lim in limitations:
        story.append(Paragraph(f"<b>[{lim.get('id')}] {lim.get('title')}</b> ({lim.get('category')}):", bullet_style))
        story.append(Paragraph(f"{lim.get('description')}", ParagraphStyle("SubDesc", parent=bullet_style, leftIndent=25, textColor=colors.HexColor("#475569"))))

    # Section 3: Potential Research Gaps (Derived from limitations)
    story.append(Spacer(1, 10))
    story.append(Paragraph("3. Potential Research Gaps (Derived from Selected Paper)", h2_style))
    for gap in gaps:
        story.append(Paragraph(f"<b>[{gap.get('id')}] {gap.get('gap_title')}</b> (Ref: {gap.get('associated_limitation_id')}):", bullet_style))
        story.append(Paragraph(f"<i>Unaddressed Challenge:</i> {gap.get('gap_description')}", ParagraphStyle("SubGap", parent=bullet_style, leftIndent=25, textColor=colors.HexColor("#475569"))))

    # Section 4: Recommended Further Implementations / Future Work
    story.append(Spacer(1, 10))
    story.append(Paragraph("4. Recommended Further Implementation & Engineering Roadmap", h2_style))
    for rec in recommendations:
        story.append(Paragraph(f"<b>[{rec.get('id')}] {rec.get('title')}</b>", bullet_style))
        story.append(Paragraph(f"<b>Expected Impact:</b> {rec.get('expected_impact')} | <b>Tools:</b> {rec.get('recommended_tools')}", ParagraphStyle("RecMeta", parent=bullet_style, leftIndent=25, textColor=colors.HexColor("#0284c7"))))
        for step in rec.get("technical_steps", []):
            story.append(Paragraph(f"&bull; {step}", ParagraphStyle("Step", parent=bullet_style, leftIndent=35, textColor=colors.HexColor("#334155"))))

    doc.build(story)
    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes
