"""
UI Components and Layout Helpers for Research Gap Finder.
Maintains consistent layout, sidebar status, and workflow navigation across all pages.
"""

import streamlit as st
import os
from config import APP_TITLE, VERSION, SESSION_KEYS


def render_sidebar():
    """Renders a clean, unified sidebar on every page."""
    with st.sidebar:
        st.markdown(f"### 📚 {APP_TITLE}")
        st.caption(f"**{VERSION}**")
        st.markdown("---")

        # System Status Cards
        papers = st.session_state.get(SESSION_KEYS["papers"], [])
        analyzed = st.session_state.get(SESSION_KEYS["analysis"], [])
        best_paper = st.session_state.get(SESSION_KEYS["best_paper"], None)

        st.markdown("#### 📌 Workflow Status")
        st.write(f"• **Uploaded Papers:** `{len(papers)}`")
        if analyzed:
            st.write(f"• **Analyzed:** `{len(analyzed)}`")
        if best_paper:
            st.success(f"**Selected Best Paper:**\n\n{best_paper['title'][:40]}...")
            st.metric("Best Paper Score", f"{best_paper['overall_score']} / 100")
        else:
            st.info("No paper selected yet. Please upload and run analysis.")

        st.markdown("---")

        # Analysis Mode Settings (Offline Local NLP vs OpenAI)
        st.markdown("#### ⚙️ Engine Settings")
        mode = st.radio(
            "Analysis Engine:",
            ["Offline / Local NLP (No API Key)", "OpenAI API (Optional)"],
            index=0 if st.session_state.get(SESSION_KEYS["analysis_mode"]) == "Offline / Local NLP" else 1,
            help="Offline / Local NLP runs 100% locally without any external API keys - ideal for viva presentations."
        )

        if "Offline" in mode:
            st.session_state[SESSION_KEYS["analysis_mode"]] = "Offline / Local NLP"
            st.caption("🟢 Running 100% offline using deterministic NLP & heuristic pattern matching.")
        else:
            st.session_state[SESSION_KEYS["analysis_mode"]] = "OpenAI API"
            api_key = st.text_input(
                "OpenAI API Key:",
                value=st.session_state.get(SESSION_KEYS["openai_api_key"], os.getenv("OPENAI_API_KEY", "")),
                type="password",
                help="Enter your OpenAI API key or set it in .env"
            )
            st.session_state[SESSION_KEYS["openai_api_key"]] = api_key
            if not api_key:
                st.warning("⚠️ No OpenAI API key entered. Will automatically fall back to Local NLP if run.")

        st.markdown("---")
        if st.button("🔄 Reset Project / Clear Session", use_container_width=True):
            for k in SESSION_KEYS.values():
                if k in st.session_state:
                    del st.session_state[k]
            st.rerun()


def render_page_header(title: str, subtitle: str, step_num: int = 1, total_steps: int = 6):
    """Renders a standard clean page header with a step indicator."""
    col1, col2 = st.columns([4, 1])
    with col1:
        st.title(title)
        st.caption(subtitle)
    with col2:
        st.markdown(f"<div style='text-align: right; padding-top: 15px; font-weight: bold; color: #0284c7;'>"
                    f"Step {step_num} of {total_steps}</div>", unsafe_allow_html=True)
    st.markdown("---")
