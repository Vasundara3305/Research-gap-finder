"""
Sample Paper Generator for Research Gap Finder.
Generates 3 realistic academic research paper PDFs using ReportLab.
Enables immediate 1-click testing and demonstration for B.Tech project viva evaluation.
"""

import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


def generate_sample_papers(output_dir: str = "sample_papers") -> list:
    """Generates 3 sample research paper PDFs in output_dir and returns their filepaths."""
    os.makedirs(output_dir, exist_ok=True)
    generated_files = []

    papers = [
        {
            "filename": "Paper_1_FedHealth.pdf",
            "title": "FedHealth: A Robust Federated Learning Architecture for Privacy-Preserving Clinical Diagnosis",
            "authors": "Dr. Ramesh Sharma, Priya Patel, Kevin Anderson",
            "institution": "Department of Computer Science & Health Informatics, Tech University",
            "abstract": (
                "Deep learning models for medical image diagnostics require vast, diverse datasets typically "
                "scattered across separate healthcare institutions. Traditional centralized data aggregation faces "
                "stringent privacy regulations (HIPAA, GDPR) and significant patient confidentiality concerns. "
                "In this work, we propose FedHealth, a federated learning framework integrating Differential Privacy "
                "with Stochastic Gradient Descent (DP-SGD) and verifiable secure multiparty aggregation. We evaluate "
                "FedHealth across a heterogeneous multi-center consortium comprising 12 hospital nodes and 150,000 "
                "anonymized chest X-ray and CT scans. Experimental results demonstrate that FedHealth achieves a diagnostic "
                "accuracy of 94.2% (AUC: 0.978), closely matching centralized training (95.1%) while ensuring strict "
                "differential privacy guarantees (epsilon = 1.8, delta = 1e-5). Rigorous ablation studies confirm "
                "robust convergence even under significant non-IID data distributions."
            ),
            "introduction": (
                "Collaborative healthcare analytics offers unprecedented potential for early detection of pulmonary "
                "pathologies. However, hospital data silos hinder the development of generalizable diagnostic models. "
                "Centralizing sensitive patient records poses severe liability and regulatory compliance risks. "
                "Federated learning has emerged as a promising paradigm, yet real-world healthcare deployments face "
                "critical hurdles: communication latency across hospital networks, client drift caused by non-IID patient "
                "demographics, and susceptibility to model inversion attacks."
            ),
            "methodology": (
                "The FedHealth architecture incorporates three core components: (1) A ResNet-50 backbone modified with "
                "group normalization layers to stabilize training across disparate medical imaging devices; (2) An adaptive "
                "client-weighting FedAvg algorithm that penalizes divergence on local gradient updates; and (3) Layer-wise "
                "gradient clipping combined with calibrated Gaussian noise addition for differential privacy. "
                "Each hospital node computes gradients locally on on-premise GPU clusters, encrypts updates using a 2048-bit "
                "Paillier cryptosystem, and transmits only masked parameters to the central coordinator."
            ),
            "results": (
                "We benchmark FedHealth on the CheXpert, MIMIC-CXR, and NIH Chest X-ray14 datasets partitioned across 12 "
                "simulated hospital nodes. On pneumonia and cardiomegaly detection, FedHealth obtains 94.2% diagnostic accuracy, "
                "outperforming standard FedAvg by 6.4% and FedProx by 3.8%. Extensive ablation studies indicate that privacy "
                "budget epsilon = 1.8 incurs less than a 1.0% drop in overall F1 score compared to non-private baselines. "
                "Communication rounds to convergence were reduced from 220 rounds in standard FedAvg to 118 rounds using our "
                "adaptive momentum aggregation strategy."
            ),
            "limitations": (
                "Despite strong diagnostic performance, FedHealth exhibits notable limitations: "
                "First, communication overhead remains substantial: exchanging encrypted model parameters across constrained "
                "hospital WAN uplinks requires over 450 MB bandwidth per round. "
                "Second, while our architecture mitigates moderate non-IID shifts, performance drops by 7.3% when a hospital node "
                "contains severe class imbalance (e.g., fewer than 2% positive pathology instances). "
                "Third, FedHealth lacks an automated Byzantine-robust filtering mechanism against malicious hospital nodes "
                "attempting gradient poisoning or label-flipping attacks. "
                "Fourth, inference has only been validated on high-end workstation GPUs (NVIDIA RTX 4090 / A100), leaving "
                "compatibility with low-resource edge diagnostic devices and embedded hospital carts unaddressed."
            ),
            "conclusion": (
                "FedHealth provides a clinically viable, privacy-preserving federated diagnostic architecture capable of "
                "collaborative multi-center training without sharing raw patient scans. Future extensions must focus on "
                "gradient compression techniques, Byzantine fault tolerance, and lightweight edge inference."
            )
        },
        {
            "filename": "Paper_2_VisionLite.pdf",
            "title": "VisionLite: Ultra-Lightweight Mobile Object Detection with 4-Bit Integer Quantization",
            "authors": "Ananya Roy, Daniel Becker, Marcus Chen",
            "institution": "Embedded AI Lab, Institute of Technology",
            "abstract": (
                "Real-time object detection on resource-constrained mobile and embedded platforms requires minimizing "
                "latency and memory consumption without drastically degrading mean Average Precision (mAP). We introduce "
                "VisionLite, an ultra-compact convolutional architecture utilizing inverted bottleneck blocks combined with "
                "post-training 4-bit integer (INT4) weight quantization and 8-bit (INT8) activation quantization. Evaluated on "
                "the MS COCO benchmark, VisionLite achieves 28.4 mAP while operating at 124 frames per second (FPS) on a "
                "Snapdragon 888 NPU with a memory footprint of just 4.2 MB."
            ),
            "introduction": (
                "Modern object detectors such as YOLO and Faster R-CNN deliver high accuracy but demand substantial computational "
                "and memory bandwidth, making on-device battery-operated deployment impractical. Existing mobile backbones such as "
                "MobileNetV3 and ShuffleNet suffer accuracy loss when pushed into ultra-low bitwidth regimes. This paper tackles "
                "the problem of stabilizing quantization noise in sub-8-bit mobile detectors."
            ),
            "methodology": (
                "VisionLite employs depthwise separable convolutions with customized kernel sizes (3x3 and 5x5) and introduces "
                "a Hessian-aware scale factor for layer-wise INT4 weight quantization. An asymmetric clip-and-scale function "
                "minimizes outliers in activation distributions. Training is carried out in two phases: full-precision FP32 pre-training "
                "followed by Quantization-Aware Training (QAT) with learnable step size parameters."
            ),
            "results": (
                "On MS COCO minival, VisionLite scores 28.4 mAP (0.50:0.95), trailing MobileNetV3-SSD by only 1.5 mAP while cutting "
                "model weight storage by 62% (from 11.2 MB to 4.2 MB). Average power consumption measured on a physical smartphone "
                "was 1.15 Watts, representing a 3.2x battery longevity improvement over FP32 alternatives."
            ),
            "limitations": (
                "VisionLite is evaluated strictly on standard natural daylight photographs in MS COCO; detection accuracy degrades "
                "sharply under adverse conditions such as low-light nocturnal scenes, dense fog, and rainy driving environments. "
                "Furthermore, the INT4 hardware acceleration relies on Qualcomm Hexagon DSP instructions and is not natively portable "
                "to Apple Neural Engine or ARM Cortex microcontrollers."
            ),
            "conclusion": (
                "VisionLite demonstrates that ultra-low bitwidth quantization can deliver real-time mobile object detection with "
                "minimal latency. Future investigations should investigate cross-hardware portability and robust domain adaptation."
            )
        },
        {
            "filename": "Paper_3_EdgeSensorNet.pdf",
            "title": "EdgeSensorNet: Tiny Transformer for Real-Time Industrial Vibration Anomaly Detection",
            "authors": "Vikram Malhotra, Sofia Lindqvist",
            "institution": "School of Industrial Engineering & Applied Cybernetics",
            "abstract": (
                "Predictive maintenance in modern industrial manufacturing requires real-time detection of mechanical anomalies "
                "from high-frequency vibration telemetry. While Transformer models capture long-range temporal dependencies "
                "effectively, their quadratic self-attention complexity prevents execution on low-power IoT microcontrollers. "
                "We present EdgeSensorNet, a micro-transformer featuring linear causal attention and fixed-size chunking. "
                "Evaluated on the NASA C-MAPSS turbofan dataset and the IMS bearing dataset, EdgeSensorNet attains an F1 score "
                "of 91.5% with an inference footprint of 180 KB RAM, fitting on an ARM Cortex-M4 microcontroller."
            ),
            "introduction": (
                "Unplanned industrial equipment downtime accounts for billions of dollars in annual manufacturing losses. "
                "Traditional threshold-based vibration monitoring yields excessive false alarms, while modern Transformer models "
                "are too resource-intensive to execute directly on vibration sensors installed on rotating machinery."
            ),
            "methodology": (
                "EdgeSensorNet employs a 1D convolutional feature tokenizer followed by a 2-layer Transformer encoder with "
                "linearized kernelized self-attention. Instead of computing full N-by-N attention matrices, we compute a rolling "
                "linear dot product over fixed 128-sample temporal windows. The total model parameter count is 86,000."
            ),
            "results": (
                "On the NASA C-MAPSS dataset, EdgeSensorNet achieves an F1 score of 91.5% and a Root Mean Square Error (RMSE) of "
                "14.2 on Remaining Useful Life (RUL) estimation. End-to-end inference latency on an STM32F401RE MCU clocked at "
                "84 MHz is 14.2 ms per window, using 42 mW operating power."
            ),
            "limitations": (
                "The evaluation was conducted exclusively on synthetic testbed datasets (C-MAPSS and IMS) rather than operational "
                "factory floors with unpredictable mechanical shock noise and varying rotational speeds. Moreover, the model requires "
                "manual tuning of the temporal window size (128 samples) for each individual machinery type."
            ),
            "conclusion": (
                "EdgeSensorNet enables real-time edge anomaly classification directly on microcontroller sensors. Extending this to "
                "self-supervised online adaptation remains a key avenue for next-generation industrial telemetry."
            )
        }
    ]

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "PaperTitle",
        parent=styles["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=15,
        leading=18,
        textColor=colors.HexColor("#1e293b"),
        alignment=1, # Center
        spaceAfter=8
    )
    author_style = ParagraphStyle(
        "PaperAuthors",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=10,
        leading=13,
        textColor=colors.HexColor("#475569"),
        alignment=1,
        spaceAfter=4
    )
    inst_style = ParagraphStyle(
        "PaperInst",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#64748b"),
        alignment=1,
        spaceAfter=14
    )
    sec_heading_style = ParagraphStyle(
        "SectionHeading",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=12,
        leading=15,
        textColor=colors.HexColor("#0f172a"),
        spaceBefore=10,
        spaceAfter=4
    )
    body_style = ParagraphStyle(
        "PaperBody",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9.5,
        leading=13.5,
        textColor=colors.HexColor("#334155"),
        spaceAfter=8
    )
    abstract_style = ParagraphStyle(
        "AbstractBody",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=9.5,
        leading=13.5,
        textColor=colors.HexColor("#1e293b"),
        spaceBefore=4,
        spaceAfter=10
    )

    for p in papers:
        filepath = os.path.join(output_dir, p["filename"])
        doc = SimpleDocTemplate(
            filepath,
            pagesize=letter,
            rightMargin=45,
            leftMargin=45,
            topMargin=45,
            bottomMargin=45
        )
        story = []

        # Title & Authors
        story.append(Paragraph(p["title"], title_style))
        story.append(Paragraph(p["authors"], author_style))
        story.append(Paragraph(p["institution"], inst_style))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#cbd5e1"), spaceAfter=10))

        # Abstract
        story.append(Paragraph("<b>ABSTRACT</b>", sec_heading_style))
        story.append(Paragraph(p["abstract"], abstract_style))

        # Introduction
        story.append(Paragraph("<b>1. INTRODUCTION</b>", sec_heading_style))
        story.append(Paragraph(p["introduction"], body_style))

        # Methodology
        story.append(Paragraph("<b>2. METHODOLOGY & ARCHITECTURE</b>", sec_heading_style))
        story.append(Paragraph(p["methodology"], body_style))

        # Results
        story.append(Paragraph("<b>3. EXPERIMENTAL VALIDATION & RESULTS</b>", sec_heading_style))
        story.append(Paragraph(p["results"], body_style))

        # Limitations
        story.append(Paragraph("<b>4. LIMITATIONS</b>", sec_heading_style))
        story.append(Paragraph(p["limitations"], body_style))

        # Conclusion
        story.append(Paragraph("<b>5. CONCLUSION & FUTURE WORK</b>", sec_heading_style))
        story.append(Paragraph(p["conclusion"], body_style))

        doc.build(story)
        generated_files.append(filepath)

    return generated_files


if __name__ == "__main__":
    files = generate_sample_papers("sample_papers")
    print(f"Generated {len(files)} sample research papers in sample_papers/")
