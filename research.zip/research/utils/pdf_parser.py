"""
PDF Parser Module for Research Gap Finder.
Extracts raw text, title, abstract, and key sections from uploaded research papers (PDFs).
Uses pdfplumber with a robust fallback to pypdf.
"""

import io
import re
from typing import Dict, Any, Optional

try:
    import pdfplumber
except ImportError:
    pdfplumber = None

try:
    import pypdf
except ImportError:
    pypdf = None


def extract_text_from_pdf_bytes(file_bytes: bytes, filename: str = "paper.pdf") -> Dict[str, Any]:
    """
    Extracts text and basic metadata from PDF byte stream.
    Falls back gracefully between pdfplumber and pypdf.
    """
    text_pages = []
    total_pages = 0
    error_msg = None

    # Try pdfplumber first
    if pdfplumber is not None:
        try:
            with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                total_pages = len(pdf.pages)
                for idx, page in enumerate(pdf.pages):
                    page_text = page.extract_text() or ""
                    text_pages.append(page_text)
        except Exception as e:
            error_msg = f"pdfplumber extraction error: {str(e)}"

    # If pdfplumber failed or produced empty text, try pypdf
    full_text = "\n\n".join(text_pages).strip()
    if (not full_text or error_msg) and pypdf is not None:
        try:
            reader = pypdf.PdfReader(io.BytesIO(file_bytes))
            total_pages = len(reader.pages)
            text_pages = []
            for page in reader.pages:
                page_text = page.extract_text() or ""
                text_pages.append(page_text)
            full_text = "\n\n".join(text_pages).strip()
            error_msg = None
        except Exception as e:
            error_msg = f"pypdf extraction error: {str(e)}"

    if not full_text:
        return {
            "success": False,
            "filename": filename,
            "error": error_msg or "No extractable text found in PDF (file may be image-only/scanned or corrupted).",
            "page_count": total_pages,
            "full_text": "",
            "title": filename.replace(".pdf", "").replace("_", " ").title(),
            "abstract": "",
            "sections": {}
        }

    # Normalize whitespace
    full_text = re.sub(r"\r\n", "\n", full_text)
    full_text = re.sub(r"[ \t]+", " ", full_text)

    # Heuristic Title extraction from first page
    title = _extract_title(text_pages[0] if text_pages else full_text, filename)
    abstract = _extract_abstract(full_text)
    sections = _extract_sections(full_text)

    return {
        "success": True,
        "filename": filename,
        "page_count": total_pages,
        "full_text": full_text,
        "title": title,
        "abstract": abstract,
        "sections": sections,
        "word_count": len(full_text.split()),
        "error": None
    }


def _extract_title(first_page_text: str, filename: str) -> str:
    """Heuristically extracts paper title from the top lines of the first page."""
    if not first_page_text:
        return filename.replace(".pdf", "").replace("_", " ").title()

    lines = [line.strip() for line in first_page_text.split("\n") if line.strip()]
    candidate_lines = []

    for line in lines[:10]:
        lower = line.lower()
        # Skip headers, journal names, arxiv timestamps
        if any(skip in lower for skip in ["arxiv:", "ieee", "springer", "acm", "proceedings", "conference", "volume", "issn", "doi:"]):
            continue
        if len(line) < 5 or line.isdigit():
            continue
        if "abstract" in lower:
            break
        candidate_lines.append(line)
        if len(" ".join(candidate_lines)) > 120:
            break

    if candidate_lines:
        title = " ".join(candidate_lines)
        # Clean trailing symbols
        title = re.sub(r"\s+", " ", title).strip()
        if len(title) > 10:
            return title[:180]

    return filename.replace(".pdf", "").replace("_", " ").title()


def _extract_abstract(full_text: str) -> str:
    """Extracts the abstract section if present."""
    match = re.search(r"(?i)\babstract\b[\s:\-–—]*(.*?)(?=\b(?:1\.?\s+|i\.?\s+|introduction|keywords|index terms)\b)", full_text, re.DOTALL)
    if match:
        abstract = match.group(1).strip()
        # Clean up line wraps
        abstract = re.sub(r"\s+", " ", abstract)
        if len(abstract) > 40:
            return abstract[:1500]

    # Fallback: take first 1200 characters of the text
    paragraphs = [p.strip() for p in full_text.split("\n\n") if len(p.strip()) > 80]
    if paragraphs:
        return paragraphs[0][:800]
    return full_text[:600]


def _extract_sections(full_text: str) -> Dict[str, str]:
    """Identifies and extracts key academic sections."""
    section_patterns = {
        "methodology": r"(?i)\b(?:methodology|proposed method|system architecture|model architecture|approach|proposed framework|algorithm)\b[\s:\-–—]*(.*?)(?=\b(?:experiments?|results?|evaluation|performance|discussion|limitations?|conclusion)\b)",
        "results": r"(?i)\b(?:results?|experimental results?|evaluation|performance analysis|benchmark results?)\b[\s:\-–—]*(.*?)(?=\b(?:discussion|limitations?|related work|future work|conclusion|references)\b)",
        "limitations": r"(?i)\b(?:limitations?|threats to validity|current constraints?|drawbacks?)\b[\s:\-–—]*(.*?)(?=\b(?:future work|conclusion|acknowledgments?|references)\b)",
        "conclusion": r"(?i)\b(?:conclusion|concluding remarks|summary and conclusion)\b[\s:\-–—]*(.*?)(?=\b(?:acknowledgments?|references|appendix)\b)"
    }

    extracted = {}
    for sec_name, pattern in section_patterns.items():
        match = re.search(pattern, full_text, re.DOTALL)
        if match:
            text = match.group(1).strip()
            text = re.sub(r"\s+", " ", text)
            if len(text) > 50:
                extracted[sec_name] = text[:2500]
            else:
                extracted[sec_name] = ""
        else:
            extracted[sec_name] = ""

    return extracted
