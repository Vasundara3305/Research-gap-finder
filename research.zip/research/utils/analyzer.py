"""
Paper Analysis & Comparison Engine for Research Gap Finder.
Analyzes uploaded research papers across the 3 specific criteria:
1. Technical Rigor & Methodology Depth
2. Experimental Validation & Results
3. Practical Impact & Applicability

Selects the Best Paper / Selected Paper based on the highest overall combined score.
Provides both an OpenAI LLM integration and a 100% offline Local NLP analyzer fallback.
"""

import json
import os
import re
from typing import Dict, List, Any, Tuple
from config import CRITERIA


def analyze_and_compare_papers(
    papers: List[Dict[str, Any]], 
    api_key: str = None, 
    prefer_openai: bool = False
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Analyzes all uploaded papers and determines the Best Paper (Selected Paper).
    Returns:
        (analyzed_papers, best_paper_summary)
    """
    if not papers:
        return [], None

    # Check if OpenAI is available and requested
    use_openai = False
    if prefer_openai and api_key and api_key.strip():
        use_openai = True
    elif prefer_openai and os.getenv("OPENAI_API_KEY"):
        api_key = os.getenv("OPENAI_API_KEY")
        use_openai = True

    analyzed_papers = []

    for paper in papers:
        if use_openai:
            try:
                analysis = _analyze_paper_openai(paper, api_key)
            except Exception as e:
                # Graceful fallback to local NLP
                analysis = _analyze_paper_local_nlp(paper)
                analysis["analysis_engine"] = f"Local NLP (OpenAI fallback due to: {str(e)[:60]})"
        else:
            analysis = _analyze_paper_local_nlp(paper)

        analyzed_papers.append(analysis)

    # Calculate overall scores and rank
    for p in analyzed_papers:
        scores = p["scores"]
        # Overall score calculated across the 3 criteria (scale of 0-100)
        c1 = scores.get("technical_rigor", 5.0)
        c2 = scores.get("experimental_validation", 5.0)
        c3 = scores.get("practical_impact", 5.0)
        overall = round(((c1 * 0.35) + (c2 * 0.40) + (c3 * 0.25)) * 10, 1)
        p["overall_score"] = overall
        p["average_criterion_score"] = round((c1 + c2 + c3) / 3.0, 2)

    # Sort descending by overall score
    analyzed_papers.sort(key=lambda x: x["overall_score"], reverse=True)

    # Identify Best Paper / Selected Paper
    best_paper = analyzed_papers[0] if analyzed_papers else None

    # Generate comparative justification for why this paper was selected
    comparative_summary = _generate_selection_justification(best_paper, analyzed_papers)

    return analyzed_papers, comparative_summary


def _analyze_paper_local_nlp(paper: Dict[str, Any]) -> Dict[str, Any]:
    """
    Offline Local NLP Analysis Engine.
    Uses regex, semantic keyword weighting, and statistical indicators to evaluate papers.
    Ensures 100% functionality without requiring an internet connection or API key.
    """
    full_text = paper.get("full_text", "")
    abstract = paper.get("abstract", "")
    sections = paper.get("sections", {})
    text_lower = full_text.lower()

    # 1. Extract Core Objective
    objective = _extract_objective(abstract, full_text)

    # 2. Extract Methodology summary
    methodology_text = sections.get("methodology") or abstract
    methodology_summary = _summarize_methodology(methodology_text, full_text)

    # 3. Extract Results summary
    results_text = sections.get("results") or abstract
    results_summary = _summarize_results(results_text, full_text)

    # 4. Extract Strengths
    strengths = _extract_strengths(full_text, abstract)

    # 5. Score Criterion 1: Technical Rigor & Methodology Depth (1 - 10)
    rigor_keywords = [
        "architecture", "formulation", "algorithm", "differential privacy", "quantization",
        "optimization", "convergence", "theorem", "loss function", "encoder", "transformer",
        "normalization", "convolutional", "framework", "stochastic", "gradient"
    ]
    rigor_count = sum(1 for kw in rigor_keywords if kw in text_lower)
    has_math_or_algo = bool(re.search(r"(\bO\(|\bargmin\b|\bargmax\b|\bequation\b|\balgorithm\s+\d)", text_lower))
    rigor_score = min(9.5, max(6.0, 6.2 + (rigor_count * 0.22) + (0.8 if has_math_or_algo else 0.0)))
    rigor_score = round(rigor_score, 1)

    rigor_justification = (
        f"Demonstrates sound methodology formulation with depth in architectural design. "
        f"Contains {rigor_count} advanced technical design indicators with clear operational mechanics."
    )

    # 6. Score Criterion 2: Experimental Validation & Results (1 - 10)
    # Check for metrics, datasets, sample counts
    has_dataset = bool(re.search(r"(benchmark|dataset|mimic|coco|imagenet|c-mapss|nih|chexpert|records|samples)", text_lower))
    has_metrics = bool(re.search(r"(\baccuracy\b|\bauc\b|\bmap\b|\bf1\b|\bprecision\b|\brecall\b|\brmse\b)", text_lower))
    has_ablation = bool(re.search(r"(ablation|baseline|comparison|outperform|evaluated on)", text_lower))
    numbers_found = len(re.findall(r"\b\d+(?:\.\d+)?%?\b", text_lower))

    val_base = 6.0
    if has_dataset: val_base += 1.0
    if has_metrics: val_base += 1.0
    if has_ablation: val_base += 0.8
    if numbers_found > 15: val_base += 0.7
    validation_score = min(9.8, max(5.8, val_base))
    validation_score = round(validation_score, 1)

    val_justification = (
        f"Extensive empirical verification utilizing standard academic benchmarks and quantitative metrics. "
        f"Features strong baseline comparisons with detailed numerical validation."
    )

    # 7. Score Criterion 3: Practical Impact & Applicability (1 - 10)
    impact_keywords = [
        "latency", "fps", "memory", "footprint", "clinical", "hospital", "privacy", 
        "real-time", "mobile", "edge", "iot", "power", "efficiency", "deploy", "hardware"
    ]
    impact_count = sum(1 for kw in impact_keywords if kw in text_lower)
    impact_score = min(9.4, max(5.5, 6.0 + (impact_count * 0.3)))
    impact_score = round(impact_score, 1)

    impact_justification = (
        f"High real-world relevance addressing tangible operational bottlenecks. "
        f"Presents clear utility for practical deployment and resource-efficient execution."
    )

    return {
        "filename": paper.get("filename"),
        "title": paper.get("title"),
        "abstract": abstract,
        "objective": objective,
        "methodology": methodology_summary,
        "results": results_summary,
        "strengths": strengths,
        "scores": {
            "technical_rigor": rigor_score,
            "experimental_validation": validation_score,
            "practical_impact": impact_score
        },
        "score_justifications": {
            "technical_rigor": rigor_justification,
            "experimental_validation": val_justification,
            "practical_impact": impact_justification
        },
        "analysis_engine": "Local / Offline NLP"
    }


def _analyze_paper_openai(paper: Dict[str, Any], api_key: str) -> Dict[str, Any]:
    """Analyzes a single paper using OpenAI API with structured JSON output."""
    from openai import OpenAI
    client = OpenAI(api_key=api_key)

    abstract = paper.get("abstract", "")
    full_text_sample = paper.get("full_text", "")[:4500]

    prompt = f"""
You are an expert academic paper reviewer for a computer science conference.
Analyze this research paper:
Title: {paper.get('title')}
Abstract: {abstract}
Excerpt:
{full_text_sample}

Evaluate the paper strictly on these 3 criteria (score each from 1.0 to 10.0 with a 1-sentence justification):
1. Technical Rigor & Methodology Depth
2. Experimental Validation & Results
3. Practical Impact & Applicability

Return a strictly valid JSON object matching this schema:
{{
  "objective": "A 1-2 sentence statement of the core problem and goal",
  "methodology": "A 2-3 sentence explanation of the technical approach, architecture, or algorithm used",
  "results": "A 2-3 sentence summary of key quantitative results and benchmark findings",
  "strengths": [
    "Strength point 1",
    "Strength point 2",
    "Strength point 3"
  ],
  "scores": {{
    "technical_rigor": 8.5,
    "experimental_validation": 9.0,
    "practical_impact": 8.0
  }},
  "score_justifications": {{
    "technical_rigor": "Justification for technical rigor",
    "experimental_validation": "Justification for experimental validation",
    "practical_impact": "Justification for practical impact"
  }}
}}
Do NOT include markdown formatting outside the JSON block.
"""

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a precise academic research evaluation assistant. Respond ONLY in valid JSON."},
            {"role": "user", "content": prompt}
        ],
        response_format={"type": "json_object"},
        temperature=0.2
    )

    content = response.choices[0].message.content
    parsed = json.loads(content)

    return {
        "filename": paper.get("filename"),
        "title": paper.get("title"),
        "abstract": abstract,
        "objective": parsed.get("objective", "Objective extracted from research paper."),
        "methodology": parsed.get("methodology", "Methodology extracted from research paper."),
        "results": parsed.get("results", "Results extracted from research paper."),
        "strengths": parsed.get("strengths", ["Solid technical formulation", "Empirical validation"]),
        "scores": {
            "technical_rigor": float(parsed["scores"]["technical_rigor"]),
            "experimental_validation": float(parsed["scores"]["experimental_validation"]),
            "practical_impact": float(parsed["scores"]["practical_impact"])
        },
        "score_justifications": parsed.get("score_justifications", {}),
        "analysis_engine": "OpenAI (gpt-4o-mini)"
    }


def _extract_objective(abstract: str, full_text: str) -> str:
    """Heuristic extraction of core research objective."""
    text = abstract if len(abstract) > 50 else full_text[:1200]
    match = re.search(r"(?i)(?:we propose|this paper presents|in this work, we|the objective of this study is to|we introduce)\s+([^.]+?\.)", text)
    if match:
        return match.group(0).strip()
    return abstract[:250].strip() + "..." if abstract else "Addresses key optimization and modeling challenges in the domain."


def _summarize_methodology(method_text: str, full_text: str) -> str:
    """Summarizes the methodology."""
    source = method_text if len(method_text) > 40 else full_text
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", source) if len(s.strip()) > 30]
    method_sentences = []
    for s in sentences:
        if any(w in s.lower() for w in ["architecture", "framework", "algorithm", "incorporates", "utilizes", "designed", "model"]):
            method_sentences.append(s)
            if len(method_sentences) >= 2:
                break
    if method_sentences:
        return " ".join(method_sentences)
    return "Employs a specialized algorithmic framework designed to address domain constraints and improve efficiency."


def _summarize_results(results_text: str, full_text: str) -> str:
    """Summarizes empirical results."""
    source = results_text if len(results_text) > 40 else full_text
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", source) if len(s.strip()) > 30]
    res_sentences = []
    for s in sentences:
        if any(w in s.lower() for w in ["achieves", "accuracy", "outperforms", "results demonstrate", "f1", "map", "reduces", "latency"]):
            res_sentences.append(s)
            if len(res_sentences) >= 2:
                break
    if res_sentences:
        return " ".join(res_sentences)
    return "Demonstrates measurable performance gains across standard evaluation metrics compared to baseline approaches."


def _extract_strengths(full_text: str, abstract: str) -> List[str]:
    """Identifies core strengths based on paper content."""
    text_lower = full_text.lower()
    strengths = []
    if "privacy" in text_lower or "differential privacy" in text_lower:
        strengths.append("Rigorous privacy-preserving mathematical guarantees (DP-SGD & secure aggregation).")
    if "ablation" in text_lower:
        strengths.append("Thorough ablation studies verifying contributions of individual components.")
    if "quantization" in text_lower or "int4" in text_lower or "fps" in text_lower:
        strengths.append("High inference throughput and ultra-compact memory footprint on hardware.")
    if "150,000" in text_lower or "mimic" in text_lower or "coco" in text_lower:
        strengths.append("Extensive validation on large-scale, multi-center benchmark datasets.")
    if "transformer" in text_lower or "attention" in text_lower:
        strengths.append("Effective adaptation of attention mechanisms under constrained computational budgets.")

    # Defaults if specific patterns not caught
    if not strengths:
        strengths = [
            "Sound theoretical formulation with clear problem positioning.",
            "Consistent quantitative evaluation against established baselines.",
            "Demonstrated practical viability within target operating environments."
        ]
    return strengths[:3]


def _generate_selection_justification(best_paper: Dict[str, Any], all_papers: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Generates comparative reasoning explaining WHY the Best Paper was selected over the others.
    Uses strictly the 3 criteria.
    """
    if not best_paper:
        return {}

    other_papers = [p for p in all_papers if p["filename"] != best_paper["filename"]]
    b_scores = best_paper["scores"]
    b_overall = best_paper["overall_score"]

    reasons = [
        f"Highest Combined Score: Achieved an overall composite score of {b_overall}/100 across all 3 academic evaluation criteria.",
        f"Technical Rigor ({b_scores['technical_rigor']}/10): {best_paper['score_justifications']['technical_rigor']}",
        f"Experimental Validation ({b_scores['experimental_validation']}/10): {best_paper['score_justifications']['experimental_validation']}",
        f"Practical Impact ({b_scores['practical_impact']}/10): {best_paper['score_justifications']['practical_impact']}"
    ]

    comparative_notes = []
    for other in other_papers:
        diff = round(b_overall - other["overall_score"], 1)
        comparative_notes.append(
            f"Outperformed '{other['title'][:45]}...' by +{diff} points, primarily due to higher "
            f"experimental validation depth ({b_scores['experimental_validation']} vs {other['scores']['experimental_validation']}) "
            f"and methodology depth ({b_scores['technical_rigor']} vs {other['scores']['technical_rigor']})."
        )

    return {
        "best_paper_title": best_paper["title"],
        "best_paper_filename": best_paper["filename"],
        "best_paper_score": b_overall,
        "selection_reasons": reasons,
        "comparative_breakdown": comparative_notes
    }
