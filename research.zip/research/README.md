# Research Gap Finder 🎓
### Automated Academic Paper Comparison, Best Paper Selection & Research Gap Analysis
**Final-Year B.Tech Computer Science / Information Technology Capstone Project**

---

## 📌 Project Abstract

In academic literature reviews and technological project planning, researchers and undergraduate students often struggle to objectively compare competing research publications, discern the most technically sound methodology, and extract genuine unsolved limitations to motivate new project work. 

**Research Gap Finder** is an intelligent Streamlit web application designed to automate this pipeline. Users upload multiple research papers (PDF format). The system extracts raw text and section semantics, evaluates and compares each paper across **3 standard academic criteria**, and selects the single **Selected Paper (Best Paper)** with detailed comparative justification. It then isolates **limitations strictly for the Selected Paper**, formulates **potential research gaps** stemming directly from those limitations, and generates an actionable **further implementation roadmap** with practical engineering steps, visualized in a clean analytics dashboard with downloadable PDF and CSV reports.

---

## 🔄 Strict System Workflow

The application adheres to a sequential 6-stage workflow:

```
[ Step 1: Upload Multiple Papers (PDFs) ]
                    │
                    ▼
[ Step 2: Analyze & Compare across 3 Criteria ]
                    │
                    ▼
[ Step 3: Select & Justify the Best Paper / Selected Paper ]
                    │
                    ▼
[ Step 4: Extract Limitations of the Selected Paper ONLY ]
                    │
                    ▼
[ Step 5: Identify Potential Research Gaps (from Selected Paper) ]
                    │
                    ▼
[ Step 6: Recommend Further Implementation / Future Work Roadmap ]
                    │
                    ▼
[ Step 7: Simple Analytics Dashboard & Formal PDF Report Download ]
```

---

## 🎯 The 3 Core Evaluation Criteria

To select the **Best Paper** without relying on subjective keywords or arbitrary topic inputs, the system scores all candidate papers strictly across 3 foundational research pillars:

| Criterion | Weight | Academic Focus |
| :--- | :---: | :--- |
| **1. Technical Rigor & Methodology Depth** | 35% | Algorithmic depth, mathematical formulation, architectural complexity, group normalization, differential privacy, quantization, or attention mechanics. |
| **2. Experimental Validation & Results** | 40% | Large-scale multi-center benchmark datasets, quantitative metrics (Accuracy, AUC, F1, mAP, latency), depth of ablation studies, and baseline comparisons. |
| **3. Practical Impact & Applicability** | 25% | Real-world deployment feasibility, hardware resource constraints (memory footprint, battery power, latency), and practical utility. |

The paper achieving the highest combined composite score (out of 100) is designated as the **Selected Paper (Best Paper)**.

---

## ⚠️ Scope: Selected Paper Only

As per academic review standards:
- **Limitations** are shown **ONLY for the Selected Paper**.
- **Potential Research Gaps** are derived **ONLY from the selected paper's limitations**.
- **Further Implementations** are generated **ONLY to resolve those specific gaps**.

This prevents dilution across weaker papers and gives students a sharp, focused roadmap for their next engineering phase.

---

## 📁 Project Directory Structure

```
research/
├── app.py                                  # Main entry point & guided workflow visualizer
├── pages/
│   ├── 1_📁_Upload_Papers.py               # Multi-PDF uploader & text extraction
│   ├── 2_⚖️_Analyze_&_Compare.py           # 3-criteria paper analysis & Best Paper selection
│   ├── 3_⚠️_Limitations_of_Selected_Paper.py# Limitations of the Selected Paper ONLY
│   ├── 4_🎯_Potential_Research_Gaps.py      # Potential Research Gaps derived from limitations
│   ├── 5_🚀_Further_Implementation.py       # Actionable future work & engineering steps
│   └── 6_📊_Dashboard.py                   # Simple metrics, comparison bar chart & PDF export
├── utils/
│   ├── __init__.py
│   ├── pdf_parser.py                       # PDF text/metadata extraction (pdfplumber + pypdf)
│   ├── analyzer.py                         # 3-criteria scoring & comparative reasoning
│   ├── gap_finder.py                       # Limitation extraction, gap formulation & future work
│   ├── dashboard_utils.py                  # Plotly comparison bar chart & ReportLab PDF report
│   ├── sample_generator.py                 # Generates 3 realistic academic PDFs for viva demos
│   └── ui_components.py                    # Reusable sidebar status and page headers
├── sample_papers/                          # 3 pre-generated realistic benchmark research papers
│   ├── Paper_1_FedHealth.pdf               # Federated Learning for Healthcare (Selected Paper)
│   ├── Paper_2_VisionLite.pdf              # Mobile INT4 Object Detection
│   └── Paper_3_EdgeSensorNet.pdf           # Edge Transformer for Industrial Telemetry
├── config.py                               # App constants, scoring criteria & session keys
├── requirements.txt                        # Dependencies
├── .env.example                            # Template for optional OpenAI API key
├── .env                                    # Local environment variables
└── README.md                               # Project documentation & viva guide
```

---

## 🚀 Installation & Setup

### 1. Prerequisites
- Python 3.10 or higher
- Git (optional)

### 2. Clone or Navigate to Directory
```bash
cd path/to/research
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure API Key (Optional)
The project includes a **100% functional Local / Offline NLP Fallback Engine** that requires **no internet connection or API keys**.

If you wish to optionally use OpenAI:
1. Open `.env`
2. Add your key:
```env
OPENAI_API_KEY=sk-your-openai-key-here
```
Or enter it directly in the Streamlit sidebar during runtime.

---

## 💻 How to Run

Launch the Streamlit web application:

```bash
streamlit run app.py
```

The application will automatically open in your default browser at:
```
http://localhost:8501
```

---

## 🧪 1-Click Viva Demonstration Guide

For your college project viva evaluation or lab demonstration:
1. Launch the app (`streamlit run app.py`).
2. On the home page or `Upload Papers` page, click the **"📁 Load 3 Sample Papers"** button.
3. The app will immediately load 3 realistic academic papers from `sample_papers/`:
   - `Paper_1_FedHealth.pdf`
   - `Paper_2_VisionLite.pdf`
   - `Paper_3_EdgeSensorNet.pdf`
4. Click **"Go to Step 2: Analyze & Compare"** ➡️ Click **"🚀 Run Comparative Analysis"**.
5. Observe:
   - FedHealth is selected as the **Selected Paper (Best Paper)** with a composite score of 85.5/100 due to superior experimental validation (12 hospital nodes, 150,000 scans).
   - Clear comparative rationale and cross-paper comparison table.
6. Click through **Step 3 (Limitations)**, **Step 4 (Research Gaps)**, and **Step 5 (Further Implementation)**.
7. View the final **Dashboard (Step 6)** and click **"📄 Download Formal PDF Evaluation Report"** to download the generated documentation.

---

## 🎓 Viva Questions & Answers

**Q1: Why did you not use a research topic input or relevance score?**  
> *Answer:* In a standard academic literature review, researchers have already collected candidate papers in a domain. Rather than measuring subjective keyword relevance to a search query, our system evaluates the intrinsic quality and scientific merit of the papers across technical rigor, validation depth, and practical impact.

**Q2: How is the Best Paper selected?**  
> *Answer:* Each paper is evaluated on 3 dimensions: (1) Technical Rigor & Methodology Depth (35% weight), (2) Experimental Validation & Results (40% weight), and (3) Practical Impact & Applicability (25% weight). The weighted sum produces a combined score out of 100. The paper with the highest overall score is selected.

**Q3: Why are limitations and gaps shown only for the Best Paper?**  
> *Answer:* To establish an actionable research roadmap. If a weaker paper fails due to basic methodology flaws, its limitations are trivial. However, the limitations of the *strongest* paper represent the genuine state-of-the-art research frontier that needs to be addressed in future work.

**Q4: How does the system work without an API key?**  
> *Answer:* It includes a deterministic Local NLP analyzer that extracts section semantics, parses explicit limitations using regex boundary detection, quantifies dataset and baseline metrics, and maps inherent domain trade-offs to practical engineering recommendations.

---

## 📄 License & Academic Attribution
Developed as a Final-Year B.Tech Capstone Project. Open source for academic and educational evaluation.
