import os
import sys
import glob

# Ensure project root is in python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from utils.pdf_parser import extract_text_from_pdf_bytes
from utils.analyzer import analyze_and_compare_papers
from utils.gap_finder import analyze_selected_paper_gaps_and_future_work
from utils.dashboard_utils import create_score_comparison_chart, create_criteria_breakdown_table, generate_summary_pdf_report

def main():
    print("=== Testing Research Gap Finder Backend Pipeline ===")
    
    # 1. Load sample PDFs
    pdf_files = glob.glob("sample_papers/*.pdf")
    print(f"Found {len(pdf_files)} sample PDFs: {pdf_files}")
    assert len(pdf_files) >= 3, "Expected at least 3 sample PDFs."
    
    parsed_papers = []
    for f in pdf_files:
        with open(f, "rb") as fp:
            data = fp.read()
        res = extract_text_from_pdf_bytes(data, filename=os.path.basename(f))
        print(f"Parsed {res['filename']} - Pages: {res['page_count']} - Words: {res['word_count']} - Title: {res['title'][:40]}...")
        assert res["success"] is True
        assert len(res["full_text"]) > 200
        parsed_papers.append(res)
        
    # 2. Analyze & Compare Papers across the 3 criteria
    print("\n--- Running Paper Analysis & Best Paper Selection ---")
    analyzed_papers, selection_summary = analyze_and_compare_papers(parsed_papers, prefer_openai=False)
    
    best_paper = analyzed_papers[0]
    print(f"Best Paper / Selected Paper: {best_paper['title']}")
    print(f"Overall Score: {best_paper['overall_score']}/100")
    print(f"Technical Rigor: {best_paper['scores']['technical_rigor']}/10")
    print(f"Experimental Validation: {best_paper['scores']['experimental_validation']}/10")
    print(f"Practical Impact: {best_paper['scores']['practical_impact']}/10")
    
    for p in analyzed_papers:
        print(f"  * {p['title'][:40]}... -> Overall Score: {p['overall_score']}")
        
    assert "FedHealth" in best_paper["title"] or best_paper["overall_score"] >= analyzed_papers[1]["overall_score"]
    
    # 3. Limitations, Gaps, Further Implementation for the Selected Paper ONLY
    print("\n--- Extracting Limitations, Gaps & Implementation for Selected Paper ONLY ---")
    raw_best_paper = next(p for p in parsed_papers if p["filename"] == best_paper["filename"])
    gaps_result = analyze_selected_paper_gaps_and_future_work(best_paper, raw_best_paper, prefer_openai=False)
    
    limitations = gaps_result["limitations"]
    gaps = gaps_result["research_gaps"]
    recs = gaps_result["further_implementations"]
    
    print(f"Identified {len(limitations)} Limitations for Selected Paper:")
    for lim in limitations:
        print(f"  - [{lim['id']}] {lim['title']}")
        
    print(f"\nDerived {len(gaps)} Potential Research Gaps:")
    for g in gaps:
        print(f"  - [{g['id']}] {g['gap_title']} (Ref: {g['associated_limitation_id']})")
        
    print(f"\nGenerated {len(recs)} Actionable Further Implementations:")
    for r in recs:
        print(f"  - [{r['id']}] {r['title']}")
        print(f"    Impact: {r['expected_impact']}")
        
    assert len(limitations) >= 3
    assert len(gaps) >= 3
    assert len(recs) >= 3
    
    # 4. Dashboard Utilities & PDF Report
    print("\n--- Generating Chart, Table & PDF Report ---")
    fig = create_score_comparison_chart(analyzed_papers, best_paper["title"])
    assert fig is not None
    
    df = create_criteria_breakdown_table(analyzed_papers, best_paper["title"])
    print(df.to_string())
    
    pdf_bytes = generate_summary_pdf_report(analyzed_papers, best_paper, limitations, gaps, recs)
    print(f"Generated PDF summary report: {len(pdf_bytes)} bytes")
    assert len(pdf_bytes) > 1000
    
    print("\nSUCCESS: All pipeline components verified successfully!")

if __name__ == "__main__":
    main()
