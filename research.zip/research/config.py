"""
Configuration and constants for Research Gap Finder.
Designed for B.Tech Final Year Project demonstration and evaluation.
"""

import os
import streamlit as st

# Application Title & Metadata
APP_TITLE = "Research Gap Finder"
APP_SUBTITLE = "Automated Academic Paper Comparison, Best Paper Selection & Research Gap Analysis"
VERSION = "1.0 (B.Tech Final Year Project)"

# The 3 Mandatory Evaluation Criteria for Selecting Best Paper
CRITERIA = [
    {
        "id": "technical_rigor",
        "name": "Technical Rigor & Methodology Depth",
        "description": "Soundness of mathematical formulation, algorithm design, architecture depth, and theoretical validity.",
        "weight": 0.35,
        "max_score": 10
    },
    {
        "id": "experimental_validation",
        "name": "Experimental Validation & Results",
        "description": "Quality and size of datasets, ablation studies, baseline comparisons, statistical significance, and metric improvements.",
        "weight": 0.40,
        "max_score": 10
    },
    {
        "id": "practical_impact",
        "name": "Practical Impact & Applicability",
        "description": "Real-world feasibility, deployment potential, scalability, resource efficiency, and problem relevance.",
        "weight": 0.25,
        "max_score": 10
    }
]

# Session State Keys
SESSION_KEYS = {
    "papers": "papers_data",                       # Parsed PDFs
    "analysis": "analyzed_papers",                 # Per-paper analysis & scores
    "best_paper": "best_paper",                    # Selected Paper object
    "limitations": "best_paper_limitations",       # Limitations of Selected Paper ONLY
    "research_gaps": "best_paper_gaps",            # Gaps of Selected Paper ONLY
    "further_work": "best_paper_recommendations",  # Further implementations for Selected Paper ONLY
    "analysis_complete": "analysis_complete",      # Boolean flag
    "analysis_mode": "analysis_mode",              # 'Offline / Local NLP' or 'OpenAI API'
    "openai_api_key": "openai_api_key"             # Optional API key
}

def init_session_state():
    """Initializes all necessary Streamlit session state variables."""
    for key, name in SESSION_KEYS.items():
        if name not in st.session_state:
            if key in ["papers", "analysis", "limitations", "research_gaps", "further_work"]:
                st.session_state[name] = []
            elif key == "best_paper":
                st.session_state[name] = None
            elif key == "analysis_complete":
                st.session_state[name] = False
            elif key == "analysis_mode":
                st.session_state[name] = "Offline / Local NLP"
            elif key == "openai_api_key":
                st.session_state[name] = os.getenv("OPENAI_API_KEY", "")
