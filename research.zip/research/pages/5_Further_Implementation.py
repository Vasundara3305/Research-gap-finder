"""
Step 5: Recommend Further Implementation / Future Work (Selected Paper ONLY)
Provides actionable, concrete engineering proposals to resolve the research gaps
and limitations of the single Selected Best Paper.
"""

import streamlit as st
from config import APP_TITLE, init_session_state, SESSION_KEYS
from utils.ui_components import render_sidebar, render_page_header

st.set_page_config(page_title=f"Further Implementation - {APP_TITLE}", page_icon="🚀", layout="wide")
init_session_state()
render_sidebar()

render_page_header(
    title="🚀 Recommended Further Implementation / Future Work",
    subtitle="Concrete, actionable technical proposals designed to bridge the gaps of the Selected Paper.",
    step_num=5,
    total_steps=6
)

best_paper = st.session_state.get(SESSION_KEYS["best_paper"], None)
recs = st.session_state.get(SESSION_KEYS["further_work"], [])

if not best_paper or not recs:
    st.warning("⚠️ Implementation recommendations have not been generated yet.")
    if st.button("⬅️ Go to Step 4: Potential Research Gaps"):
        st.switch_page("pages/4_Potential_Research_Gaps.py")
    st.stop()

# Context Header
st.markdown(f"""
<div style='background-color:#eff6ff; border-left:5px solid #0284c7; padding:15px; border-radius:6px; margin-bottom:20px;'>
    <div style='font-size:12px; font-weight:bold; color:#0369a1; text-transform:uppercase;'>Implementation Roadmap for Selected Paper</div>
    <h3 style='margin:4px 0 6px 0; color:#1e293b;'>{best_paper['title']}</h3>
    <span style='color:#475569; font-size:13px;'>Generated <b>{len(recs)} actionable engineering proposal(s)</b> with step-by-step milestones.</span>
</div>
""", unsafe_allow_html=True)

st.markdown("### 🛠️ Practical Implementation Proposals")
st.write("Each proposal outlines a viable B.Tech / M.Tech extension or research development roadmap:")

for idx, rec in enumerate(recs):
    with st.expander(f"📌 [{rec.get('id', f'REC-{idx+1}')}] **{rec.get('title')}**", expanded=True):
        m1, m2, m3 = st.columns(3)
        with m1:
            st.markdown(f"**Associated Gap:** `{rec.get('associated_gap_id', 'GAP-1')}`")
        with m2:
            st.markdown(f"**Feasibility:** `{rec.get('feasibility', 'High')}`")
        with m3:
            st.markdown(f"**Recommended Tools:** `{rec.get('recommended_tools', 'PyTorch')}`")

        st.markdown(f"""
        <div style='background-color:#ecfdf5; border-left:4px solid #10b981; padding:10px 14px; border-radius:4px; margin: 10px 0;'>
            <b>🎯 Expected Impact:</b> {rec.get('expected_impact')}
        </div>
        """, unsafe_allow_html=True)

        st.markdown("##### 📋 Step-by-Step Technical Execution Plan:")
        for step_idx, step in enumerate(rec.get("technical_steps", [])):
            st.markdown(f"**Step {step_idx + 1}:** {step}")

st.markdown("---")
# Navigation
nav1, nav2 = st.columns([3, 1])
with nav1:
    st.write("Ready to view the consolidated analytics dashboard and download the final report?")
with nav2:
    if st.button("Go to Step 6: Dashboard ➡️", type="primary", use_container_width=True):
        st.switch_page("pages/6_Dashboard.py")
