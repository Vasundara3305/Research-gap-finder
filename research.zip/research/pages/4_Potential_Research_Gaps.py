"""
Step 4: Potential Research Gaps (Derived from Selected Paper's Limitations ONLY)
Formulates rigorous academic research gaps directly mapped to the limitations
identified in the Selected Paper.
"""

import streamlit as st
from config import APP_TITLE, init_session_state, SESSION_KEYS
from utils.ui_components import render_sidebar, render_page_header

st.set_page_config(page_title=f"Potential Research Gaps - {APP_TITLE}", page_icon="🎯", layout="wide")
init_session_state()
render_sidebar()

render_page_header(
    title="🎯 Potential Research Gaps",
    subtitle="Formulated directly from the limitations of the Selected Best Paper.",
    step_num=4,
    total_steps=6
)

best_paper = st.session_state.get(SESSION_KEYS["best_paper"], None)
limitations = st.session_state.get(SESSION_KEYS["limitations"], [])
gaps = st.session_state.get(SESSION_KEYS["research_gaps"], [])

if not best_paper or not limitations:
    st.warning("⚠️ Limitations have not been loaded yet. Please complete the previous steps.")
    if st.button("⬅️ Go to Step 3: Limitations"):
        st.switch_page("pages/3_Limitations_of_Selected_Paper.py")
    st.stop()

# Context Header
st.markdown(f"""
<div style='background-color:#eff6ff; border-left:5px solid #3b82f6; padding:15px; border-radius:6px; margin-bottom:20px;'>
    <div style='font-size:12px; font-weight:bold; color:#1d4ed8; text-transform:uppercase;'>Target Selected Paper</div>
    <h3 style='margin:4px 0 6px 0; color:#1e293b;'>{best_paper['title']}</h3>
    <span style='color:#475569; font-size:13px;'>Deriving research frontiers from <b>{len(limitations)} limitation(s)</b>.</span>
</div>
""", unsafe_allow_html=True)

st.markdown("### 📌 Research Gap Formulations")
st.write("Each research gap below targets an unaddressed scientific or architectural frontier stemming directly from a known limitation:")

for idx, gap in enumerate(gaps):
    with st.container():
        st.markdown(f"""
        <div style='background-color:#f8fafc; border:1px solid #cbd5e1; border-radius:8px; padding:18px; margin-bottom:15px; box-shadow:0 1px 3px rgba(0,0,0,0.05);'>
            <div style='display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;'>
                <span style='background-color:#2563eb; color:white; padding:3px 10px; border-radius:12px; font-weight:bold; font-size:12px;'>
                    {gap.get('id', f'GAP-{idx+1}')}
                </span>
                <span style='background-color:#fef3c7; color:#92400e; padding:3px 10px; border-radius:6px; font-size:12px; font-weight:600;'>
                    🔗 Solves Limitation: <b>{gap.get('associated_limitation_id', 'LIM-1')}</b>
                </span>
            </div>
            <h4 style='color:#1e3a8a; margin-top:6px; margin-bottom:8px;'>{gap.get('gap_title')}</h4>
            <div style='background-color:#ffffff; border-left:3px solid #60a5fa; padding:10px 12px; margin-bottom:8px; border-radius:4px;'>
                <span style='font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase;'>Unaddressed Research Problem:</span>
                <p style='color:#334155; font-size:14px; margin-top:4px; margin-bottom:0;'>
                    {gap.get('gap_description')}
                </p>
            </div>
            <p style='color:#0f766e; font-size:13.5px; margin-bottom:0;'>
                <b>🌟 Academic Significance:</b> {gap.get('academic_significance')}
            </p>
        </div>
        """, unsafe_allow_html=True)

# Navigation
st.markdown("---")
nav1, nav2 = st.columns([3, 1])
with nav1:
    st.write("Ready to explore concrete engineering steps and future work recommendations?")
with nav2:
    if st.button("Go to Step 5: Further Implementation ➡️", type="primary", use_container_width=True):
        st.switch_page("pages/5_Further_Implementation.py")
