"""
Step 2: Analyze & Compare Papers -> Select Best Paper
Compares all uploaded papers based on:
1. Technical Rigor & Methodology Depth
2. Experimental Validation & Results
3. Practical Impact & Applicability

Calculates overall scores and selects the Best Paper (Selected Paper) with comparative rationale.
"""

import streamlit as st
from config import APP_TITLE, init_session_state, SESSION_KEYS
from utils.ui_components import render_sidebar, render_page_header
from utils.analyzer import analyze_and_compare_papers
from utils.dashboard_utils import create_criteria_breakdown_table

st.set_page_config(page_title=f"Analyze & Compare - {APP_TITLE}", page_icon="⚖️", layout="wide")
init_session_state()
render_sidebar()

render_page_header(
    title="⚖️ Analyze & Compare Papers → Select Best Paper",
    subtitle="Evaluate research content, methodology, and results across 3 standard academic criteria.",
    step_num=2,
    total_steps=6
)

papers = st.session_state.get(SESSION_KEYS["papers"], [])

if not papers:
    st.warning("⚠️ No uploaded papers found in session. Please upload papers first.")
    if st.button("⬅️ Go Back to Step 1: Upload Papers"):
        st.switch_page("pages/1_Upload_Papers.py")
    st.stop()

# Analysis trigger controls
analyzed_papers = st.session_state.get(SESSION_KEYS["analysis"], [])
best_paper = st.session_state.get(SESSION_KEYS["best_paper"], None)
engine_mode = st.session_state.get(SESSION_KEYS["analysis_mode"], "Offline / Local NLP")
api_key = st.session_state.get(SESSION_KEYS["openai_api_key"], "")

col_ctrl1, col_ctrl2 = st.columns([3, 1])
with col_ctrl1:
    st.info(f"⚡ Ready to evaluate **{len(papers)} paper(s)** using the **{engine_mode}**.")
with col_ctrl2:
    run_btn = st.button("🚀 Run Comparative Analysis", type="primary", use_container_width=True)

if run_btn or not analyzed_papers:
    with st.spinner("Analyzing methodology, empirical results, and computing 3-criteria scores..."):
        prefer_openai = ("OpenAI" in engine_mode and bool(api_key.strip()))
        analyzed_list, selection_summary = analyze_and_compare_papers(
            papers,
            api_key=api_key,
            prefer_openai=prefer_openai
        )
        st.session_state[SESSION_KEYS["analysis"]] = analyzed_list
        if analyzed_list:
            st.session_state[SESSION_KEYS["best_paper"]] = analyzed_list[0]
            st.session_state["selection_summary"] = selection_summary
        
        # Reset downstream results when re-analyzing
        st.session_state[SESSION_KEYS["limitations"]] = []
        st.session_state[SESSION_KEYS["research_gaps"]] = []
        st.session_state[SESSION_KEYS["further_work"]] = []
        analyzed_papers = analyzed_list
        best_paper = analyzed_list[0] if analyzed_list else None
        st.success("Comparative analysis completed successfully!")

if analyzed_papers and best_paper:
    # -------------------------------------------------------------
    # SECTION 1: THE SELECTED BEST PAPER SHOWCASE
    # -------------------------------------------------------------
    st.markdown("---")
    st.markdown("### 🏆 Selected Paper (Best Paper)")
    
    st.markdown(f"""
    <div style='background-color:#f0fdf4; border:2px solid #22c55e; border-radius:10px; padding:20px; margin-bottom:20px;'>
        <div style='display:flex; justify-content:space-between; align-items:center;'>
            <span style='background-color:#16a34a; color:white; padding:4px 12px; border-radius:15px; font-weight:bold; font-size:13px;'>
                ★ HIGHEST OVERALL SCORE
            </span>
            <span style='font-size:18px; font-weight:bold; color:#15803d;'>
                Overall Score: {best_paper['overall_score']} / 100
            </span>
        </div>
        <h2 style='color:#0f172a; margin-top:10px; margin-bottom:8px;'>{best_paper['title']}</h2>
        <p style='color:#334155; font-size:14px; margin-bottom:12px;'><b>File:</b> <code>{best_paper['filename']}</code> | <b>Analysis Engine:</b> {best_paper.get('analysis_engine', 'Local NLP')}</p>
        <p style='color:#1e293b; font-size:15px; line-height:1.5;'><b>Core Objective:</b> {best_paper.get('objective', '')}</p>
    </div>
    """, unsafe_allow_html=True)

    # 3 Criteria Score Badges for Selected Paper
    scores = best_paper["scores"]
    sc_col1, sc_col2, sc_col3 = st.columns(3)
    with sc_col1:
        st.metric(
            label="Technical Rigor & Methodology",
            value=f"{scores['technical_rigor']} / 10",
            help="Soundness of mathematical formulation and architectural depth."
        )
        st.caption(f"_{best_paper['score_justifications'].get('technical_rigor', '')}_")

    with sc_col2:
        st.metric(
            label="Experimental Validation & Results",
            value=f"{scores['experimental_validation']} / 10",
            help="Quality of benchmarks, baseline comparisons, and statistical metrics."
        )
        st.caption(f"_{best_paper['score_justifications'].get('experimental_validation', '')}_")

    with sc_col3:
        st.metric(
            label="Practical Impact & Applicability",
            value=f"{scores['practical_impact']} / 10",
            help="Deployment viability, resource efficiency, and problem relevance."
        )
        st.caption(f"_{best_paper['score_justifications'].get('practical_impact', '')}_")

    # Why this paper was selected
    with st.expander("🔍 Comparative Selection Rationale (Why this paper was selected)", expanded=True):
        st.markdown("**Academic Comparative Justification:**")
        summary = st.session_state.get("selection_summary", {})
        for reason in summary.get("selection_reasons", []):
            st.markdown(f"• {reason}")
        if summary.get("comparative_breakdown"):
            st.markdown("**Comparison Against Other Candidates:**")
            for comp in summary.get("comparative_breakdown", []):
                st.markdown(f"• {comp}")

    # -------------------------------------------------------------
    # SECTION 2: COMPARISON TABLE ACROSS ALL PAPERS
    # -------------------------------------------------------------
    st.markdown("---")
    st.markdown("### 📊 Cross-Paper Comparison Matrix")
    st.write("Comparison of all analyzed papers across the 3 mandatory evaluation criteria:")

    comp_df = create_criteria_breakdown_table(analyzed_papers, best_paper["title"])
    st.dataframe(comp_df, use_container_width=True, hide_index=True)

    # -------------------------------------------------------------
    # SECTION 3: INDIVIDUAL PAPER DETAILS (TABS)
    # -------------------------------------------------------------
    st.markdown("---")
    st.markdown("### 📑 Detailed Paper Profiles")
    tabs = st.tabs([f"Paper {i+1}: {p['title'][:25]}..." for i, p in enumerate(analyzed_papers)])

    for idx, (tab, p) in enumerate(zip(tabs, analyzed_papers)):
        with tab:
            is_best = (p["title"] == best_paper["title"])
            if is_best:
                st.success("⭐ **This is the Selected Best Paper**")
            else:
                st.info(f"Paper {idx + 1}")

            st.markdown(f"#### {p['title']}")
            st.write(f"**File:** `{p['filename']}` | **Overall Score:** `{p['overall_score']} / 100`")

            col_p1, col_p2 = st.columns(2)
            with col_p1:
                st.markdown("##### 🔬 Methodology & Technical Approach")
                st.write(p.get("methodology", "Not specified."))
                st.markdown("##### 💡 Key Strengths")
                for s in p.get("strengths", []):
                    st.write(f"• {s}")

            with col_p2:
                st.markdown("##### 📈 Experimental Results & Findings")
                st.write(p.get("results", "Not specified."))
                st.markdown("##### 📊 Scores Breakdown")
                st.write(f"• **Technical Rigor:** {p['scores']['technical_rigor']} / 10")
                st.write(f"• **Experimental Validation:** {p['scores']['experimental_validation']} / 10")
                st.write(f"• **Practical Impact:** {p['scores']['practical_impact']} / 10")

    # -------------------------------------------------------------
    # NAVIGATION TO STEP 3
    # -------------------------------------------------------------
    st.markdown("---")
    nav1, nav2 = st.columns([3, 1])
    with nav1:
        st.write("Next, we extract limitations **STRICTLY for the Selected Best Paper**.")
    with nav2:
        if st.button("Go to Step 3: Limitations ➡️", type="primary", use_container_width=True):
            st.switch_page("pages/3_Limitations_of_Selected_Paper.py")
