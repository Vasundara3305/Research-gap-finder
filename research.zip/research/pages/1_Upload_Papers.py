"""
Step 1: Upload Multiple Research Papers (PDFs)
Allows users to upload multiple research papers or load bundled sample papers.
Extracts raw text, title, abstract, and section metadata.
"""

import streamlit as st
import os
import glob
from config import APP_TITLE, init_session_state, SESSION_KEYS
from utils.ui_components import render_sidebar, render_page_header
from utils.pdf_parser import extract_text_from_pdf_bytes
from utils.sample_generator import generate_sample_papers

st.set_page_config(page_title=f"Upload Papers - {APP_TITLE}", page_icon="📁", layout="wide")
init_session_state()
render_sidebar()

render_page_header(
    title="📁 Upload Multiple Research Papers",
    subtitle="Upload two or more research papers (PDF format) for automated comparative analysis.",
    step_num=1,
    total_steps=6
)

# Instructions Banner
st.markdown("""
> **Instructions**:
> 1. Upload **2 or more research papers in PDF format** using the file uploader below.
> 2. Alternatively, click **'Load 3 Benchmark Sample Papers'** for an instant 1-click demonstration.
> 3. Verify the extracted metadata and text previews, then proceed to **Step 2: Analyze & Compare**.
""")

# Action row: Upload or Load Samples
col_uploader, col_sample = st.columns([3, 1])

with col_sample:
    st.markdown("#### ⚡ 1-Click Viva Demo")
    st.caption("Load realistic pre-generated academic papers without uploading:")
    if st.button("📁 Load 3 Sample Papers", use_container_width=True, type="secondary"):
        with st.spinner("Extracting text from sample papers..."):
            sample_dir = "sample_papers"
            if not os.path.exists(sample_dir) or len(glob.glob(os.path.join(sample_dir, "*.pdf"))) < 3:
                generate_sample_papers(sample_dir)

            sample_files = glob.glob(os.path.join(sample_dir, "*.pdf"))
            parsed_list = []
            for fpath in sample_files:
                with open(fpath, "rb") as f:
                    file_bytes = f.read()
                parsed = extract_text_from_pdf_bytes(file_bytes, filename=os.path.basename(fpath))
                if parsed["success"]:
                    parsed_list.append(parsed)

            st.session_state[SESSION_KEYS["papers"]] = parsed_list
            # Invalidate older analysis
            st.session_state[SESSION_KEYS["analysis"]] = []
            st.session_state[SESSION_KEYS["best_paper"]] = None
            st.session_state[SESSION_KEYS["limitations"]] = []
            st.session_state[SESSION_KEYS["research_gaps"]] = []
            st.session_state[SESSION_KEYS["further_work"]] = []
            st.success(f"Loaded {len(parsed_list)} sample papers successfully!")
            st.rerun()

with col_uploader:
    st.markdown("#### 📤 Upload PDF Files")
    uploaded_files = st.file_uploader(
        "Select PDF research papers:",
        type=["pdf"],
        accept_multiple_files=True,
        help="Upload multiple academic papers in PDF format."
    )

    if uploaded_files:
        if st.button(f"🔍 Parse {len(uploaded_files)} Uploaded PDF(s)", type="primary"):
            progress_bar = st.progress(0)
            status_text = st.empty()
            parsed_list = []

            for idx, uploaded_file in enumerate(uploaded_files):
                status_text.text(f"Parsing ({idx + 1}/{len(uploaded_files)}): {uploaded_file.name}...")
                file_bytes = uploaded_file.read()
                parsed = extract_text_from_pdf_bytes(file_bytes, filename=uploaded_file.name)
                
                if parsed["success"]:
                    parsed_list.append(parsed)
                else:
                    st.error(f"Failed to parse {uploaded_file.name}: {parsed.get('error')}")
                
                progress_bar.progress((idx + 1) / len(uploaded_files))

            status_text.text("Extraction complete!")
            if parsed_list:
                st.session_state[SESSION_KEYS["papers"]] = parsed_list
                # Invalidate older analysis
                st.session_state[SESSION_KEYS["analysis"]] = []
                st.session_state[SESSION_KEYS["best_paper"]] = None
                st.session_state[SESSION_KEYS["limitations"]] = []
                st.session_state[SESSION_KEYS["research_gaps"]] = []
                st.session_state[SESSION_KEYS["further_work"]] = []
                st.success(f"Successfully extracted text from {len(parsed_list)} paper(s)!")
                st.rerun()

# Display currently parsed papers
papers = st.session_state.get(SESSION_KEYS["papers"], [])

if papers:
    st.markdown("---")
    st.markdown(f"### 📑 Extracted Papers ({len(papers)} Total)")

    for idx, p in enumerate(papers):
        with st.expander(f"📄 Paper {idx + 1}: **{p['title']}** (`{p['filename']}`)", expanded=(idx == 0)):
            m_col1, m_col2, m_col3 = st.columns(3)
            with m_col1:
                st.metric("Total Pages", p.get("page_count", 1))
            with m_col2:
                st.metric("Word Count", f"{p.get('word_count', 0):,}")
            with m_col3:
                secs_found = [k.capitalize() for k, v in p.get("sections", {}).items() if v]
                st.write(f"**Detected Sections:** {', '.join(secs_found) if secs_found else 'Standard Body'}")

            st.markdown("##### 📝 Extracted Abstract / Overview:")
            st.info(p.get("abstract", "No abstract detected."))

            with st.expander("🔍 View Raw Text Sample"):
                st.text(p.get("full_text", "")[:1200] + "\n\n[... Text truncated for display ...]")

    # Navigation to Next Step
    st.markdown("---")
    nav_col1, nav_col2 = st.columns([3, 1])
    with nav_col1:
        st.write("Ready to analyze these papers across the 3 criteria?")
    with nav_col2:
        if st.button("Go to Step 2: Analyze & Compare ➡️", type="primary", use_container_width=True):
            st.switch_page("pages/2_Analyze_and_Compare.py")
else:
    st.warning("⚠️ No papers loaded yet. Please upload PDF files or click 'Load 3 Sample Papers' above.")
