"""
Step 3: Limitations of the Selected Paper (Best Paper ONLY)
Extracts and displays limitations STRICTLY for the single chosen Selected Paper.
No limitations of other candidate papers are shown.
"""

import streamlit as st
from config import APP_TITLE, init_session_state, SESSION_KEYS
from utils.ui_components import render_sidebar, render_page_header
from utils.gap_finder import analyze_selected_paper_gaps_and_future_work

st.set_page_config(page_title=f"Limitations of Selected Paper - {APP_TITLE}", page_icon="⚠️", layout="wide")
init_session_state()
render_sidebar()

render_page_header(
    title="⚠️ Limitations of the Selected Paper",
    subtitle="In-depth limitation extraction strictly for the top-ranked Best Paper.",
    step_num=3,
    total_steps=6
)

best_paper = st.session_state.get(SESSION_KEYS["best_paper"], None)
papers = st.session_state.get(SESSION_KEYS["papers"], [])

if not best_paper:
    st.warning("⚠️ No Best Paper selected yet. Please complete Step 2 first.")
    if st.button("⬅️ Go to Step 2: Analyze & Compare"):
        st.switch_page("pages/2_Analyze_and_Compare.py")
    st.stop()

# Header Card showing the Selected Paper
st.markdown(f"""
<div style='background-color:#eff6ff; border-left:5px solid #2563eb; padding:15px; border-radius:6px; margin-bottom:20px;'>
    <div style='font-size:12px; font-weight:bold; color:#1d4ed8; text-transform:uppercase;'>Scope: Selected Paper ONLY</div>
    <h3 style='margin:4px 0 6px 0; color:#1e293b;'>{best_paper['title']}</h3>
    <span style='color:#475569; font-size:13px;'>File: <code>{best_paper['filename']}</code> | Overall Score: <b>{best_paper['overall_score']} / 100</b></span>
</div>
""", unsafe_allow_html=True)

# Fetch or extract limitations
limitations = st.session_state.get(SESSION_KEYS["limitations"], [])
engine_mode = st.session_state.get(SESSION_KEYS["analysis_mode"], "Offline / Local NLP")
api_key = st.session_state.get(SESSION_KEYS["openai_api_key"], "")

if not limitations:
    with st.spinner("Extracting inherent limitations for the Selected Paper..."):
        raw_paper = next((p for p in papers if p["filename"] == best_paper["filename"]), None)
        prefer_openai = ("OpenAI" in engine_mode and bool(api_key.strip()))
        
        gaps_result = analyze_selected_paper_gaps_and_future_work(
            best_paper,
            raw_paper,
            api_key=api_key,
            prefer_openai=prefer_openai
        )
        
        st.session_state[SESSION_KEYS["limitations"]] = gaps_result["limitations"]
        st.session_state[SESSION_KEYS["research_gaps"]] = gaps_result["research_gaps"]
        st.session_state[SESSION_KEYS["further_work"]] = gaps_result["further_implementations"]
        limitations = gaps_result["limitations"]

# Display Limitations
st.markdown("### 🔍 Identified Inherent Limitations")
st.write(f"Identified **{len(limitations)} core limitation(s)** specifically in this work:")

for idx, lim in enumerate(limitations):
    with st.container():
        st.markdown(f"""
        <div style='background-color:#fff7ed; border:1px solid #fed7aa; border-radius:8px; padding:18px; margin-bottom:15px;'>
            <div style='display:flex; justify-content:space-between; align-items:center;'>
                <span style='background-color:#ea580c; color:white; padding:3px 10px; border-radius:12px; font-weight:bold; font-size:12px;'>
                    {lim.get('id', f'LIM-{idx+1}')}
                </span>
                <span style='background-color:#ffedd5; color:#9a3412; padding:3px 8px; border-radius:6px; font-size:12px; font-weight:600;'>
                    📂 {lim.get('category', 'Technical Scope')}
                </span>
            </div>
            <h4 style='color:#9a3412; margin-top:10px; margin-bottom:8px;'>{lim.get('title')}</h4>
            <p style='color:#334155; font-size:14.5px; line-height:1.5; margin-bottom:0;'>
                {lim.get('description')}
            </p>
        </div>
        """, unsafe_allow_html=True)

# Important Note
st.info(
    "💡 **Academic Note for Viva Review:** "
    "Limitations highlight boundaries where even the highest-ranked research paper encounters trade-offs. "
    "In the next step, each of these limitations will directly formulate an unexplored **Potential Research Gap**."
)

# Navigation
st.markdown("---")
nav1, nav2 = st.columns([3, 1])
with nav1:
    st.write("Ready to transform these limitations into actionable research gaps?")
with nav2:
    if st.button("Go to Step 4: Research Gaps ➡️", type="primary", use_container_width=True):
        st.switch_page("pages/4_Potential_Research_Gaps.py")
