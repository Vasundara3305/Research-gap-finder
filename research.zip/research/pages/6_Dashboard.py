"""
Step 6: Interactive Dashboard & Exportable Report
Provides a clean, simple analytics dashboard showing:
1. Total papers
2. Best Paper name & overall score
3. Number of limitations
4. Number of potential research gaps
5. Number of further implementation suggestions
6. Simple comparison bar chart of paper scores
7. One-click downloadable PDF and CSV reports
"""

import streamlit as st
import pandas as pd
from config import APP_TITLE, init_session_state, SESSION_KEYS
from utils.ui_components import render_sidebar, render_page_header
from utils.dashboard_utils import (
    create_score_comparison_chart,
    create_criteria_breakdown_table,
    generate_summary_pdf_report
)

st.set_page_config(page_title=f"Dashboard - {APP_TITLE}", page_icon="📊", layout="wide")
init_session_state()
render_sidebar()

render_page_header(
    title="📊 Research Analytics Dashboard",
    subtitle="Consolidated evaluation overview, score comparisons, and downloadable project report.",
    step_num=6,
    total_steps=6
)

analyzed_papers = st.session_state.get(SESSION_KEYS["analysis"], [])
best_paper = st.session_state.get(SESSION_KEYS["best_paper"], None)
limitations = st.session_state.get(SESSION_KEYS["limitations"], [])
gaps = st.session_state.get(SESSION_KEYS["research_gaps"], [])
recs = st.session_state.get(SESSION_KEYS["further_work"], [])

if not analyzed_papers or not best_paper:
    st.warning("⚠️ No analysis data found. Please complete the previous steps.")
    if st.button("⬅️ Go to Step 1: Upload Papers"):
        st.switch_page("pages/1_Upload_Papers.py")
    st.stop()

# -------------------------------------------------------------
# 1. CORE DASHBOARD METRICS (Requested by User)
# -------------------------------------------------------------
st.markdown("### 📌 Project Summary Metrics")

m_col1, m_col2, m_col3, m_col4, m_col5, m_col6 = st.columns(6)

with m_col1:
    st.metric(
        label="Total Papers",
        value=len(analyzed_papers),
        help="Total number of uploaded and analyzed research papers."
    )

with m_col2:
    short_title = best_paper["title"][:22] + "..." if len(best_paper["title"]) > 22 else best_paper["title"]
    st.metric(
        label="Selected Best Paper",
        value=short_title,
        help=f"Full title: {best_paper['title']}"
    )

with m_col3:
    st.metric(
        label="Best Paper Score",
        value=f"{best_paper['overall_score']} / 100",
        help="Combined score across the 3 core criteria."
    )

with m_col4:
    st.metric(
        label="Limitations (Selected)",
        value=len(limitations),
        help="Number of limitations extracted for the Selected Paper ONLY."
    )

with m_col5:
    st.metric(
        label="Research Gaps",
        value=len(gaps),
        help="Number of potential research gaps derived from the Selected Paper's limitations."
    )

with m_col6:
    st.metric(
        label="Implementations",
        value=len(recs),
        help="Number of practical further work / future implementation suggestions."
    )

st.markdown("---")

# -------------------------------------------------------------
# 2. SCORE COMPARISON BAR CHART (Requested by User)
# -------------------------------------------------------------
col_chart, col_side = st.columns([3, 2])

with col_chart:
    st.markdown("### 📈 Quality Score Comparison Chart")
    st.caption("Clean comparison of overall scores across all uploaded papers (Selected Best Paper in green):")
    chart = create_score_comparison_chart(analyzed_papers, best_paper["title"])
    st.plotly_chart(chart, use_container_width=True)

with col_side:
    st.markdown("### 🏆 Selected Paper Spotlight")
    st.markdown(f"""
    <div style='background-color:#f0fdf4; border:1px solid #86efac; border-radius:8px; padding:15px; margin-bottom:15px;'>
        <b style='color:#16a34a; font-size:12px; text-transform:uppercase;'>Selected Best Paper:</b>
        <h4 style='color:#0f172a; margin-top:4px; margin-bottom:8px;'>{best_paper['title']}</h4>
        <p style='color:#334155; font-size:13.5px; margin-bottom:10px;'>{best_paper.get('objective', '')}</p>
        <div style='font-size:13px; color:#15803d; font-weight:600;'>
            • Rigor: {best_paper['scores']['technical_rigor']}/10 | Validation: {best_paper['scores']['experimental_validation']}/10 | Impact: {best_paper['scores']['practical_impact']}/10
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("#### 📂 Quick Stats")
    st.write(f"• **Analysis Engine Used:** `{best_paper.get('analysis_engine', 'Local NLP')}`")
    st.write(f"• **Identified Limitations:** `{len(limitations)}`")
    st.write(f"• **Formulated Research Gaps:** `{len(gaps)}`")
    st.write(f"• **Actionable Proposals:** `{len(recs)}`")

# -------------------------------------------------------------
# 3. COMPARISON TABLE
# -------------------------------------------------------------
st.markdown("---")
st.markdown("### 📋 Paper Comparison Table")
df = create_criteria_breakdown_table(analyzed_papers, best_paper["title"])
st.dataframe(df, use_container_width=True, hide_index=True)

# -------------------------------------------------------------
# 4. DOWNLOADABLE REPORTS (PDF & CSV)
# -------------------------------------------------------------
st.markdown("---")
st.markdown("### 📥 Export Project Evaluation Reports")
st.write("Generate and download formal academic documentation suitable for B.Tech project viva submission:")

rep_col1, rep_col2 = st.columns(2)

with rep_col1:
    # PDF Report Download
    with st.spinner("Preparing PDF report..."):
        pdf_bytes = generate_summary_pdf_report(
            analyzed_papers=analyzed_papers,
            best_paper=best_paper,
            limitations=limitations,
            gaps=gaps,
            recommendations=recs
        )
    
    st.download_button(
        label="📄 Download Formal PDF Evaluation Report",
        data=pdf_bytes,
        file_name="Research_Gap_Finder_Evaluation_Report.pdf",
        mime="application/pdf",
        type="primary",
        use_container_width=True,
        help="Complete publication-style PDF summarizing the analysis, limitations, gaps, and recommendations."
    )

with rep_col2:
    # CSV Download
    csv_data = df.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="📊 Download Scores Matrix (CSV)",
        data=csv_data,
        file_name="Paper_Comparison_Scores.csv",
        mime="text/csv",
        use_container_width=True,
        help="Export raw scores across the 3 criteria as a CSV file."
    )

st.markdown("<br><br>", unsafe_allow_html=True)
st.success("✅ **Workflow Complete!** All stages from Paper Upload to Further Implementation & Dashboard have been successfully executed.")
