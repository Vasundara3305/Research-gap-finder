"""
Research Gap Finder - Main Entry Point (Streamlit Application)
Final Year B.Tech Project
Automated Academic Paper Comparison, Best Paper Selection & Research Gap Analysis
"""

import streamlit as st
import os
import glob
from config import APP_TITLE, APP_SUBTITLE, VERSION, init_session_state, SESSION_KEYS
from utils.ui_components import render_sidebar
from utils.sample_generator import generate_sample_papers
from utils.pdf_parser import extract_text_from_pdf_bytes

# Configure Streamlit page
st.set_page_config(
    page_title=f"{APP_TITLE} - B.Tech Project",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state variables
init_session_state()

# Render unified sidebar
render_sidebar()

# Main Header
st.title(f"🎓 {APP_TITLE}")
st.markdown(f"**{APP_SUBTITLE}** | `{VERSION}`")
st.markdown("---")

# Overview Banner
st.info(
    "👋 **Welcome to Research Gap Finder!** This system helps researchers analyze multiple uploaded academic papers (PDF format), "
    "evaluates their methodology and empirical results across 3 standard criteria, selects the single **Best Paper (Selected Paper)**, "
    "extracts its limitations, identifies potential research gaps, and formulates practical recommendations for further implementation."
)

st.markdown("### 📋 System Workflow Architecture")
st.markdown(
    """
    The application follows a strictly structured sequential workflow designed for clarity and academic rigor:
    """
)

# Interactive Workflow Diagram
col1, col2, col3, col4, col5, col6 = st.columns(6)

with col1:
    st.markdown("""
    <div style='background-color:#f8fafc; padding:15px; border-radius:8px; border:1px solid #e2e8f0; text-align:center;'>
        <div style='font-size:24px;'>📁</div>
        <b>Step 1</b><br>
        <span style='font-size:12px; color:#475569;'>Upload Multiple PDFs & Extract Text</span>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div style='background-color:#f8fafc; padding:15px; border-radius:8px; border:1px solid #e2e8f0; text-align:center;'>
        <div style='font-size:24px;'>⚖️</div>
        <b>Step 2</b><br>
        <span style='font-size:12px; color:#475569;'>Analyze & Compare (3 Criteria)</span>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div style='background-color:#f8fafc; padding:15px; border-radius:8px; border:1px solid #e2e8f0; text-align:center;'>
        <div style='font-size:24px;'>🏆</div>
        <b>Step 3</b><br>
        <span style='font-size:12px; color:#475569;'>Select Best Paper with Rationale</span>
    </div>
    """, unsafe_allow_html=True)

with col4:
    st.markdown("""
    <div style='background-color:#f8fafc; padding:15px; border-radius:8px; border:1px solid #e2e8f0; text-align:center;'>
        <div style='font-size:24px;'>⚠️</div>
        <b>Step 4</b><br>
        <span style='font-size:12px; color:#475569;'>Limitations of Selected Paper ONLY</span>
    </div>
    """, unsafe_allow_html=True)

with col5:
    st.markdown("""
    <div style='background-color:#f8fafc; padding:15px; border-radius:8px; border:1px solid #e2e8f0; text-align:center;'>
        <div style='font-size:24px;'>🎯</div>
        <b>Step 5</b><br>
        <span style='font-size:12px; color:#475569;'>Derive Potential Research Gaps</span>
    </div>
    """, unsafe_allow_html=True)

with col6:
    st.markdown("""
    <div style='background-color:#f8fafc; padding:15px; border-radius:8px; border:1px solid #e2e8f0; text-align:center;'>
        <div style='font-size:24px;'>📊</div>
        <b>Step 6</b><br>
        <span style='font-size:12px; color:#475569;'>Further Work & Dashboard</span>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# The 3 Criteria Description
st.markdown("### 🎯 The 3 Core Evaluation Criteria for Best Paper Selection")
st.markdown("Unlike generic keyword matching, papers are evaluated strictly across 3 foundational research pillars:")

c_col1, c_col2, c_col3 = st.columns(3)
with c_col1:
    st.markdown("""
    #### 1. Technical Rigor & Methodology Depth
    - Mathematical soundness and theoretical formulation
    - Algorithmic design complexity and architectural innovation
    - Clarity of technical operational mechanisms
    """)

with c_col2:
    st.markdown("""
    #### 2. Experimental Validation & Results
    - Evaluation across standard multi-center datasets
    - Quantitative metric gains (Accuracy, AUC, F1, mAP, Latency)
    - Depth of ablation studies and baseline comparisons
    """)

with c_col3:
    st.markdown("""
    #### 3. Practical Impact & Applicability
    - Real-world deployment viability (edge/cloud/embedded)
    - Resource efficiency (memory footprint, battery power)
    - Direct relevance to pressing domain challenges
    """)

st.markdown("---")

# Quick Actions
st.markdown("### 🚀 Get Started")

qa_col1, qa_col2 = st.columns(2)

with qa_col1:
    st.markdown("#### Option A: Quick Viva Demo (1-Click Sample Load)")
    st.write("Automatically loads 3 benchmark research papers from `sample_papers/` for immediate offline demonstration:")
    if st.button("📁 Load 3 Sample Papers & Start", use_container_width=True, type="primary"):
        with st.spinner("Loading benchmark sample papers..."):
            sample_dir = "sample_papers"
            if not os.path.exists(sample_dir) or len(glob.glob(os.path.join(sample_dir, "*.pdf"))) < 3:
                generate_sample_papers(sample_dir)

            sample_files = glob.glob(os.path.join(sample_dir, "*.pdf"))
            parsed_list = []
            for fpath in sample_files:
                with open(fpath, "rb") as f:
                    file_bytes = f.read()
                parsed = extract_text_from_pdf_bytes(file_bytes, filename=os.path.basename(fpath))
                if parsed["success"]:
                    parsed_list.append(parsed)

            st.session_state[SESSION_KEYS["papers"]] = parsed_list
            st.success(f"Successfully loaded {len(parsed_list)} sample research papers!")
            st.switch_page("pages/1_Upload_Papers.py")

with qa_col2:
    st.markdown("#### Option B: Upload Your Own Research Papers")
    st.write("Navigate to the Upload page to upload custom research papers in PDF format:")
    if st.button("📤 Go to PDF Upload Page", use_container_width=True):
        st.switch_page("pages/1_Upload_Papers.py")

# Session Status Summary if papers loaded
papers = st.session_state.get(SESSION_KEYS["papers"], [])
if papers:
    st.markdown("---")
    st.markdown("### 📑 Currently Loaded Papers")
    for idx, p in enumerate(papers):
        st.write(f"**{idx + 1}. {p['title']}** (`{p['filename']}`) - {p['word_count']} words, {p['page_count']} pages")
